    <script src="<?=base_url();?>/main_assets/js/jquery.min.js"></script>
    <script src="<?=base_url();?>/main_assets/js/tether.min.js"></script>
    <script src="<?=base_url();?>/main_assets/js/bootstrap.min.js"></script>
    <script src="<?=base_url();?>/main_assets/js/animsition.min.js"></script>
    <script src="<?=base_url();?>/main_assets/js/bootstrap-slider.min.js"></script>
    <script src="<?=base_url();?>/main_assets/js/jquery.isotope.min.js"></script>
    <script src="<?=base_url();?>/main_assets/js/headroom.js"></script>
    <script src="<?=base_url();?>/main_assets/js/foodpicky.min.js"></script>