    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?=base_url();?>/main_assets/images/delivery.png">
    <title>Food Fasters - Guntur</title>
    <!-- Bootstrap core CSS -->
    <link href="<?=base_url();?>/main_assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url();?>/main_assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?=base_url();?>/main_assets/css/animsition.min.css" rel="stylesheet">
    <link href="<?=base_url();?>/main_assets/css/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?=base_url();?>/main_assets/css/style.css" rel="stylesheet"> 