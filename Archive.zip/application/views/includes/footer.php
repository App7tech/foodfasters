<footer class="footer">
            <div class="container">
                <!-- bottom footer statrs -->
                <div class="bottom-footer">
                    <div class="row">
                        <div class="col-xs-12 col-sm-4 footer-logo-block color-gray">
                            <a href="#"> <img src="<?=base_url();?>/main_assets/images/food-picky-logo.png" alt="Footer logo"> </a> 
                            <span>Order Delivery &amp; Take-Out </span>
                        </div>
                        <div class="col-xs-12 col-sm-4 address color-gray">
                            <h5>Address</h5>
                            <p>Concept design of oline food order and deliveye, planned as restaurant directory</p>
                        </div>
                        <div class="col-xs-12 col-sm-4 payment-options color-gray">
                            <h5>Payment Options</h5>
                            <ul>
                                <li>
                                    <a href="#"> <img src="<?=base_url();?>/main_assets/images/paypal.png" alt="Paypal"> </a>
                                </li>
                                <li>
                                    <a href="#"> <img src="<?=base_url();?>/main_assets/images/mastercard.png" alt="Mastercard"> </a>
                                </li>
                                <li>
                                    <a href="#"> <img src="<?=base_url();?>/main_assets/images/maestro.png" alt="Maestro"> </a>
                                </li>
                                <li>
                                    <a href="#"> <img src="<?=base_url();?>/main_assets/images/stripe.png" alt="Stripe"> </a>
                                </li>
                                <li>
                                    <a href="#"> <img src="<?=base_url();?>/main_assets/images/bitcoin.png" alt="Bitcoin"> </a>
                                </li>
                            </ul>
                        </div>

                    </div>
                    <p style="text-align: center;">© 2018 Copyrights, Designed by App7tech</p>
                </div>
                <!-- bottom footer ends -->
            </div>
        </footer>